package com.operations;

public class Multiplication implements OP {

	@Override
	public int calculate(int a, int b) {
		return a*b;
	}

}
