package com.operations;

public interface OP {
	public int calculate(int a, int b);
}
