package com.operations;

public class Subtraction implements OP {

	@Override
	public int calculate(int a, int b) {
		return a-b;
	}

}
